package com.example.EBDEMO.model;

public class SalesPred {

}
