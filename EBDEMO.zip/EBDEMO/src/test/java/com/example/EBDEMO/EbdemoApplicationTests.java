package com.example.EBDEMO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
